# Developer Guide

## Project Layout
- `App.tsx`: orchestrates prompts, AI calls, state, simulation, scheduling, history, and downloads.
- `components/Sidebar.tsx`: navigation between dashboard, data sources, pipelines, history, version control, schedule.
- `components/PipelineGraph.tsx`: D3 DAG renderer with zoom/pan and draggable nodes; saves positions via callback.
- `components/CodeBlock.tsx`: code viewer/editor with copy, accept, and refinement input.
- `services/geminiService.ts`: OpenAI SDK client and JSON-schema-enforced `generatePipeline` function.
- `types.ts`: shared types for pipelines, steps, validation issues, and scheduling.

## Scripts
- `npm run dev` — start Vite dev server.
- `npm run build` — production build.
- `npm run preview` — preview the production build.

## Development Notes
- React 19 with TypeScript and Vite 6; no server-side code.
- D3 graph uses simple heuristics to place source/transform/sink layers; node positions are overridable and savable.
- Simulation is deterministic by step order with randomized metrics to emulate runtime signals.
- Downloads are built client-side with JSZip; filenames are sanitized from pipeline names.
- Validation summary is purely display; upstream model must supply messages of type `info|warning|error|success`.

## Extensibility Ideas
- Persist saved layouts, history, and versions to localStorage or a backend.
- Add lint/format tooling (ESLint/Prettier) and tests.
- Support multiple DAG engines or infra targets by adjusting the system prompt and schema.
- Replace mock data sources with real connection tests and metadata.
