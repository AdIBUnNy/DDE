# Prompt & Safety Notes

## Crafting Effective Prompts
- State the data sources, transforms, and sinks explicitly (e.g., "read from S3, clean with Pandas, load to Postgres").
- Include quality gates and validations you want (schema checks, null handling, outlier rules).
- Request observability (logging, metrics, alerts) and failure handling (retries, SLAs).
- Mention scheduling expectations (daily at 02:00 UTC, cron expression, or ad-hoc).
- Provide constraints (libraries allowed/forbidden, runtime limits, naming conventions).

## Using Reference Files
- Upload concise files that contain schemas, sample SQL, or business rules.
- Avoid oversized or unrelated files; they increase noise for the model.

## Refinement Tips
- Be specific: "Add Great Expectations checks for column X" works better than "improve validation".
- Include previous feedback when asking for iterations to keep context tight.

## Safety Considerations
- Never paste secrets in prompts or reference files; the app sends prompts to the configured AI endpoint.
- Use gateway-scoped keys with least privilege.
- Review generated Dockerfile and requirements before deploying to production.
