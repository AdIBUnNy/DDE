# Deployment Guide

## Prerequisites
- Node.js 18+
- `.env.local` with `VITE_API_KEY` (and optionally `VITE_API_BASE`, `VITE_MODEL`)

## Local Development
```bash
npm install
npm run dev
```
- Open the URL printed by Vite (default http://localhost:5173).

## Production Build
```bash
npm run build
npm run preview  # optional local preview of the build
```
- The build output is in `dist/`. Host it on any static host (e.g., S3 + CloudFront, Vercel, Netlify).

## Environment for Production
- Ensure `.env.local` (or host-specific env config) includes `VITE_API_KEY` and any overrides before building.
- Keys are embedded at build time and used client-side; use restricted/gateway keys.

## Hardening Suggestions
- Serve over HTTPS only.
- Add CSP headers to limit script origins to your CDN and API base.
- Proxy API calls through a backend that injects credentials instead of exposing them to the browser, if feasible.
