# Pipeline Generation Flow

This describes how a user prompt becomes a rendered DAG and downloadable bundle.

## 1) Prompt Assembly
- User prompt from the dashboard textarea.
- Optional reference file content is appended.
- On refinement: previous Airflow code and the user’s suggestion are included.

## 2) System Instructions
- The system prompt asks the model to act as a DDE/MBSE data engineer.
- Response must be JSON only and match a schema (enforced via `response_format.json_schema`).

## 3) API Request
- Sent through `generatePipeline` with `model`, `messages`, and JSON schema.
- `VITE_API_KEY` authenticates; optional `VITE_API_BASE` overrides the endpoint.

## 4) Response Handling
- Primary attempt: model returns JSON conforming to the schema.
- Fallback: if extra text wraps JSON, the parser slices from the first `{` to the last `}`.
- Parsed object is stored as `GeneratedPipeline`.

## 5) UI Rendering
- Validation summary cards display info/warning/error/success messages.
- DAG steps populate the D3 graph with basic heuristics to place sources, transforms, and sinks.
- Code panels show the Airflow DAG, Dockerfile, and requirements with copy, accept, and refine controls.
- Simulation walks through steps sequentially, emitting logs and mock metrics.

## 6) Persistence & Versioning
- Each generation gets an id, timestamp, and semantic version `v1.0.{n}`.
- Accepted pipelines are added to the versions list; all generations appear in history.
- Saved DAG node positions persist per pipeline id/name in local state.

## 7) Download Packaging
- JSZip builds a bundle containing:
  - `dags/<safe_name>.py`
  - `infrastructure/Dockerfile`
  - `requirements.txt`
  - `README.md` with pipeline summary
- The file name uses a sanitized pipeline title ending in `_project.zip`.
