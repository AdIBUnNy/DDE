# Environment

Configure environment variables in a `.env.local` file at the project root.

```bash
VITE_API_KEY=your_api_key_here           # Required; scoped/gateway key recommended
VITE_API_BASE=https://api.example.com/v1/ # Optional; override the OpenAI-compatible base URL
VITE_MODEL=your-model-name               # Optional; defaults to gwdg.mistral-large-instruct
```

Notes:
- The key is exposed to the browser; do not use an unrestricted production key.
- Update `VITE_MODEL` to match any model available on your gateway that supports JSON responses.
- Restart the dev server after changing environment variables.
