# User Guide

## Generate a Pipeline
1. Go to Dashboard and enter your system requirements in the textarea.
2. (Optional) upload a reference file for context.
3. Click **Synthesize Architecture** to request a pipeline from the AI.

## Review & Refine
- Inspect validation summary cards for warnings/errors.
- Browse DAG steps in the graph; drag nodes to reposition and click **Save Layout** to persist the arrangement.
- Use the code panels to view Airflow DAG, Dockerfile, and requirements. Copy or edit locally if needed.
- Click **Accept & Store** to lock a version, or **Refine Design** to send feedback for regeneration.

## Simulation
- Start simulation to step through tasks. Active tasks glow in the graph; logs and mock metrics (CPU/RAM/TPS) stream in the panel.

## Data Sources (Mock)
- Add/edit/delete data sources to mirror upstream/downstream systems. This is UI-only context for now.

## Scheduling
- Open Schedule, choose once/hourly/weekly/monthly or cron. Provide a cron expression when required and click **Deploy Timers** for confirmation feedback.

## Downloads
- Click **Download** to receive a ZIP containing the DAG, Dockerfile, requirements, and a README. The filename is derived from the pipeline name.

## History & Versions
- History tracks every generation; Version Control lists accepted pipelines tagged as `v1.0.x`.
