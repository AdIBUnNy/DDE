# Documentation Index

Welcome to the DDE AI Data Pipeline Architect docs. This app is a Vite + React front end that turns a single prompt into an Airflow DAG, infra bundle, and interactive DAG visualization with simulation and download.

## Guides
- [API Guide](API_GUIDE.md)
- [Architecture](ARCHITECTURE.md)
- [Pipeline Generation Flow](PIPELINE_GENERATION.md)
- [Environment](ENVIRONMENT.md)
- [User Guide](USER_GUIDE.md)
- [Developer Guide](DEVELOPER_GUIDE.md)
- [Deployment Guide](DEPLOYMENT_GUIDE.md)
- [Prompt & Safety Notes](PROMPT_FILTER.md)

## Quick Facts
- Tech: React 19, Vite 6, TypeScript, D3, JSZip, Lucide icons, OpenAI-compatible SDK.
- Core entrypoint: App.tsx orchestrates prompt -> AI call -> visualization -> download.
- AI output: strict JSON (DAG code, Dockerfile, requirements, steps, metrics, validation summary) rendered in the UI.
