# API Guide

This app calls an OpenAI-compatible chat completion API to generate pipeline definitions. The client runs entirely in the browser and uses the `openai` SDK with `dangerouslyAllowBrowser` enabled.

## Endpoint & Auth
- Configure environment variables in `.env.local` (see ENVIRONMENT.md): `VITE_API_KEY`, optional `VITE_API_BASE`, optional `VITE_MODEL`.
- Requests are sent via the `OpenAI` client in `services/geminiService.ts`. The base URL defaults to the vendor’s public endpoint if `VITE_API_BASE` is not set.
- The API key is required and is exposed to the browser; use a restricted key or gateway for production.

## Request Shape
- Model: defaults to `gwdg.mistral-large-instruct` unless `VITE_MODEL` overrides it.
- System prompt: instructs the model to behave as a DDE/MBSE data engineer and return JSON only.
- User prompt: built from the UI input plus optional reference file content, and (on refinement) the previous code + user suggestion.
- Response format: enforced JSON schema via `response_format.json_schema` requiring `name`, `description`, `airflowCode`, `requirements`, `dockerConfig`, `steps`, and `monitoringMetrics`; `validationSummary` is optional.

## Response Parsing
- The client expects raw JSON text. If extra text wraps the JSON, a fallback parser slices the first/last braces and retries.
- `validationSummary` is optional (the schema does not mark it `required`), so the UI guards its usage.
- Errors bubble to the UI as `Architecture computation failed.` if parsing or network fails.

## Usage Example
```ts
import { generatePipeline } from "./services/geminiService";

const result = await generatePipeline(
  "Build an S3 -> Spark -> Postgres pipeline",
  { name: "ref.txt", content: "additional context" },
  "Add cost monitoring",
  previousAirflowCode
);

console.log(result.airflowCode); // Full DAG code
console.log(result.steps);       // Step list with dependencies
```

## Returned Object
- `name`, `description`: human-readable metadata.
- `airflowCode`: complete Python DAG string.
- `requirements`: pip requirement list.
- `dockerConfig`: Dockerfile contents.
- `steps`: array of `{ id, name, description, dependencies }` for the DAG.
- `monitoringMetrics`: suggested KPIs.
- `validationSummary`: info/warning/error/success notes for display.
