# Implementation

## Task 1: Results (15 Points)

### 1.1 Baseline Comparison: ChatGPT vs. DDE AI Data Pipeline Architect

In Assignment 1, we used ChatGPT to draft an Airflow DAG for a finance ETL (CSV ingestion → cleaning → unit conversion → Postgres load → email). It delivered raw code but assumed environment details, offered no validation, and left deployment to the user. For this implementation, we kept the prompt-driven generation but wrapped it in a structured UI: the app captures a prompt and optional reference file, renders the returned JSON into code panes and a DAG graph, simulates execution, tracks history/versions, and exports a ZIP bundle. The table below compares the baseline and this implementation across the same dimensions from Assignment 1.

| Dimension | ChatGPT (Baseline) | DDE AI Data Pipeline Architect |
| --- | --- | --- |
| Input Method | Free-form chat prompt only; no structure, no file context. | Prompt box plus optional reference file upload; UI controls for reset/theme; keeps the flow consistent for every run. |
| Output Format | Raw Python DAG text in the chat window; user must copy manually. | Structured JSON is rendered into Airflow DAG code, Dockerfile text, requirements list, metrics, validation cards, and a DAG graph; one-click ZIP download bundles DAG + Dockerfile + requirements + README. |
| Operator Awareness | May emit nonexistent/deprecated operators; no checks. | No local whitelist; assumes model returns valid operators. Visual DAG helps spot odd steps; user reviews before use. |
| Validation | None—user must check syntax, imports, and logic manually. | Model-sourced validation messages (info/warning/error/success) shown as cards; no local schema/AST/Airflow validation. |
| Error Handling | No detection; errors surface only at deployment. | UI shows generation errors if the call fails; no auto-repair loop—user refines manually. |
| Environment Context | Assumes connection ids and paths exist; not verified. | Optional reference file text is injected into the prompt for context; no live environment verification or connection tests. |
| Refinement | Requires re-prompting or copy/paste of prior code. | Inline Refine Design resends prior code plus feedback to the model; preserves history, versions, and layout. |
| Documentation | Inline comments only. | Downloaded ZIP includes a generated README plus visible validation/metrics in the UI. |
| Deployment Readiness | Single Python file; user must craft Dockerfile/requirements/env. | ZIP ships DAG, Dockerfile, requirements, README; infra setup beyond that is still manual. |
| Prompt Safety | Accepts any prompt. | No strict filter; relies on user intent (safety hardening remains future work). |
| Response Time Feedback | No progress indicator. | Simulated staged progress bar and status text during generation. |
| Scalability | Single user, single thread. | Single-page front end; no backend concurrency controls or rate limits (single-user expectation). |

_Figures: Use the live UI for visual reference (prompt box, validation summary cards, DAG graph, code panes, download card)._ 

### What Went Well
Replacing raw chat output with a structured JSON-driven flow gives us schema awareness, clearer separation between design and code, and an iterative refinement loop. Rendering the Airflow DAG, Dockerfile, requirements, validation summary, metrics, and the D3 DAG graph side by side makes issues visible early and keeps the user in one screen. The refinement control preserves pipeline state and applies targeted changes instead of forcing a restart. The download bundle (DAG, Dockerfile, requirements, README) supports handoff, and layout persistence lets users keep a stable topology. Simulation and live metrics previews add a dry-run feel without needing a backend executor. Overall, the UI ties generation, inspection, refinement, and export into a single pass, improving transparency and reducing copy/paste mistakes.

### Where We Could Improve Further
The current app trusts the model for validation and does not enforce schema, AST, or Airflow checks locally; adding real validators and an auto-repair loop would catch syntax/import/operator issues before display. Operator and connection verification against a target environment are absent; integrating environment checks or an Airflow API would reduce deployment surprises. Prompt safety is minimal—an allow-list or intent filter plus rate limiting would be needed for multi-user scenarios. Persistence is in-memory only; storing history, versions, and layouts would make work recoverable. Deployment help is limited to a basic bundle; adding compose/helm manifests or scheduler wiring would close the gap to production. Finally, multi-user readiness (auth, quotas, metrics) and deeper semantic checks (e.g., SQL/path/table validations) remain open areas for hardening.

### 1.2 Key Functionalities (Detailed, Assignment 2 Style)

**Functionality 1: AI-Powered Pipeline Generation from Natural Language**  
What it does: Turns a plain-language description and an optional reference file into a structured pipeline spec.  
How it works: The dashboard collects the prompt, merges the uploaded reference text (if any), and calls `generatePipeline`. The model returns JSON containing name, description, Airflow code, Dockerfile content, requirements, steps, monitoring metrics, and optional validation messages. The app assigns an id, timestamp, and semantic version, then renders code panes, the DAG graph, metrics, and validation cards together so the user can review in one place.  
Why it matters: Moves from one-off chat code to a reproducible, reviewable specification that is easier to hand off.

**Functionality 2: DAG Visualization and Layout Save**  
What it does: Shows the pipeline as a graph you can pan, zoom, and rearrange.  
How it works: `PipelineGraph` heuristically bands nodes into sources/transforms/sinks, draws edges, and highlights the active node during simulation. Nodes are draggable; Save Layout records coordinates per pipeline id/name in local state so the same topology can be restored after refreshes or later recalls.  
Why it matters: Makes dependencies visible and preserves spatial consistency across iterations.

**Functionality 3: Iterative Refinement Loop**  
What it does: Lets users request specific changes without restarting.  
How it works: The Refine Design input collects feedback, resends the prior Airflow code plus the suggestion to the model, receives updated JSON, and replaces the current result while logging history and version tags. The original context is maintained, so users do not retype prompts.  
Why it matters: Supports focused edits, keeps lineage, and reduces copy/paste churn.

**Functionality 4: Validation Summary (Model-Sourced)**  
What it does: Displays any info/warning/error/success notes returned by the model.  
How it works: If `validationSummary` is present, the UI renders cards with type and message. There is no local schema, AST, or Airflow validation; all messages come from the model response.  
Why it matters: Provides early hints about issues, while acknowledging that enforcement depends on model quality.

**Functionality 5: Simulation & Live Metrics Preview**  
What it does: Plays through tasks and shows lightweight telemetry.  
How it works: A local simulator walks steps in order, highlights the active node, appends log lines, updates mock CPU/RAM/TPS gauges, and finishes with a small output table. No backend executor is involved.  
Why it matters: Gives a dry-run feel and quick visual feedback before any deployment.

**Functionality 6: Downloadable Export Bundle**  
What it does: Creates a deployable ZIP from the generated assets.  
How it works: JSZip packages `dags/<safe_name>.py`, `infrastructure/Dockerfile`, `requirements.txt`, and a generated README, then triggers a sanitized client-side download.  
Why it matters: Provides a ready-to-share bundle instead of isolated snippets.

**Functionality 7: Schedule Configuration (Front-End Stub)**  
What it does: Captures intended run cadence.  
How it works: Users select once/hourly/weekly/monthly/cron and can enter a cron expression; the UI shows a deploy status badge. No scheduler backend is wired.  
Why it matters: Records scheduling intent now, leaving room to connect to a scheduler later.

**Functionality 8: Reference File Ingestion**  
What it does: Injects external context (schema/config/sample SQL) into the prompt.  
How it works: A single uploaded text file is read client-side and appended to the prompt before calling the model. There is no parsing or validation on the client.  
Why it matters: Reduces re-typing and grounds generation in local specifics supplied by the user.

**Functionality 9: History, Versions, and Recall**  
What it does: Keeps an audit trail and lets users reopen accepted designs.  
How it works: Each generation is stored with a timestamp; accepted pipelines are tagged `v1.0.x` in Version Control. Users can recall any saved entry to the dashboard with its DAG layout and artifacts intact.  
Why it matters: Enables comparison, rollback, and reuse without regenerating from scratch.

### 1.3 Design Choices: User Experience and Interaction (Detailed, Assignment 2 Style)

**Referencing Interaction 1: Create a New Pipeline**  
Assignment 2 Design: The user enters a natural-language description (and optionally uploads a reference file); the system validates the prompt and renders a structured preview (code, graph, metrics, validation cards).  
Implementation Design Choices: A chat-style dashboard keeps input lightweight and familiar, with a staged progress indicator (parsing → contextualizing → DAG → code → validation → finalize) so users see work advancing. Code panes, validation cards, metrics, and the DAG graph appear together, reducing context switching and letting the user assess correctness immediately.

**Referencing Interaction 2: Feedback and Refinement**  
Assignment 2 Design: The user reviews the draft, provides feedback, and the system refines the specification iteratively.  
Implementation Design Choices: Refinement stays in-thread: the prior Airflow code plus the user’s suggestion is resent to the model, and the updated pipeline replaces the view. History and version tags record lineage so users can tell what changed without re-entering the prompt. This avoids copy/paste of code and preserves state across edits.

**Referencing Interaction 3: Environment Context and File Upload**  
Assignment 2 Design: The user uploads a reference file (schema/config/sample SQL/notes), and the system uses it to inform generation.  
Implementation Design Choices: The UI accepts one text file and injects its raw content into the prompt—no client parsing—so users can quickly supply local details without filling forms. This keeps the interaction simple while allowing the model to consider environment hints.

**Referencing Interaction 4: Validation, Preview, and Artifact Generation**  
Assignment 2 Design: The system presents validation notes, lets the user inspect code, and produces deployment artifacts for download.  
Implementation Design Choices: Any validation messages from the model are rendered as info/warning/error cards. Airflow code, Dockerfile, and requirements are shown in code panes for quick review. From the same screen, the user exports a ZIP (DAG + Dockerfile + requirements + README), keeping review and handoff in a single flow.

**Referencing Interaction 5: Simulation and Live Feedback**  
Assignment 2 Design: The user simulates execution to observe step progression and basic metrics.  
Implementation Design Choices: A front-end simulator highlights the active DAG node, streams log lines, updates mock CPU/RAM/TPS gauges, and shows a small output table. This provides instant feedback without any backend runner, giving a sense of execution order and resource signals.

**Referencing Interaction 6: Scheduling, Acceptance, and Recall**  
Assignment 2 Design: The user captures scheduling intent and can accept, store, and later recall versions.  
Implementation Design Choices: Schedule chips (once/hourly/weekly/monthly/cron) plus optional cron text record timing intent and show a deploy badge (UI-only). Accepting a pipeline tags it (v1.0.x) and stores it in Version Control/History; users can recall it to the dashboard with its saved layout and artifacts preserved for further edits.

## Task 2: Working Application (20 Points)

### Repository and Demo
- Workspace: local folder `dde_-ai-data-pipeline-architect` (Vite + React SPA).
- Tech: React 19, Vite 6, TypeScript, D3, JSZip, Lucide, OpenAI SDK.

### Step-by-Step Instructions to Run the DDE AI Data Pipeline Architect

1) **System Requirements**
- OS: Windows/macOS/Linux
- Memory: 4 GB RAM minimum (8 GB recommended)
- Node.js: 18+ (Vite 6 requirement)
- npm: included with Node
- Network: access to your configured AI endpoint
- API Access: `VITE_API_KEY` for the target OpenAI-compatible gateway

2) **Download the Project**
- Ensure the project folder is available locally (as provided in the workspace).

3) **Install Dependencies**
```bash
npm install
```

4) **Configure Environment Variables**
- Create `.env.local` in the project root:
```
VITE_API_KEY=your_api_key_here
VITE_API_BASE=https://your-api-gateway.example.com/v1/
VITE_MODEL=your-model-name
```
- Only one `.env.local` is needed. Restart `npm run dev` after changes.

5) **Start the Application**
```bash
npm run dev
```
- Open the URL shown in the terminal (default http://localhost:5173).

### Important Notes
- The app is fully client-side; your API key is used in the browser. Use a restricted/gateway key.
- There is no backend scheduler or validator service; validation is whatever the model returns.
- Layouts/history persist only in the current session state.

## Mapping to Figures (for parity with friend’s doc)
- Fig A: Prompt + validation summary + DAG graph (Dashboard view).
- Fig B: Code panels (Airflow DAG, Dockerfile, requirements) with refine/accept controls.
- Fig C: Download card showing ZIP contents and statuses.
- Fig D: Simulation panel with logs/metrics and active-node highlighting.
- Fig E: Schedule selection UI.

(Use live UI screens for these figures; the structure mirrors the sections above.)
