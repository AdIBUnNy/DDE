# Architecture

## High-Level
- React 19 + Vite SPA that runs fully client-side.
- Core state lives in `App.tsx` (prompt, generation status, result, schedule, history, versions, data sources, simulation state, saved layouts).
- AI generation handled by `services/geminiService.ts` using the OpenAI SDK with JSON Schema responses.
- Visualization with D3 (`components/PipelineGraph.tsx`) for layered DAG layout, drag-to-reposition, zoom/pan, and saved node coordinates.
- Code and refinement UI with `components/CodeBlock.tsx`; navigation via `components/Sidebar.tsx`.
- Download bundle built client-side with JSZip (DAG Python, Dockerfile, requirements.txt, README in a ZIP).

## Data Flow
1. User enters prompt (+ optional reference file) and triggers "Synthesize Architecture".
2. `generatePipeline` sends system/user prompts and receives strict JSON.
3. Result stored as `GeneratedPipeline`; history and versions tracked with timestamps and semantic versions (`v1.0.x`).
4. Steps render into the DAG graph; layout positions can be saved per pipeline id/name.
5. Simulation mode iterates through steps, updates metrics (CPU/RAM/TPS), logs activity, and marks active nodes.
6. Schedule panel stores a lightweight schedule config (`once/hourly/weekly/monthly/cron` with optional cron value).
7. Download action packages the DAG, Dockerfile, requirements, and a readme into a ZIP.

## UI Sections
- **Dashboard**: prompt input, generation controls, validation summary, DAG visualization, code panels, simulation, download, acceptance/refinement controls.
- **Data Sources**: mock list with add/edit/delete to represent upstream/downstream connections.
- **Pipelines / History / Version Control**: lightweight views to display generated or accepted versions.
- **Schedule**: cron/interval selection with deploy feedback.

## Error Handling & Resilience
- Missing API key throws early with a clear error message.
- JSON parsing has a fallback that trims extraneous text around JSON.
- UI status states: `idle`, `generating`, `completed`, `error`; deploy status has `idle|deploying|deployed|error`.

## Dependencies
- D3 for graphing; Lucide for icons; JSZip for downloads; OpenAI SDK for API calls.
- Type definitions centralized in `types.ts`.
